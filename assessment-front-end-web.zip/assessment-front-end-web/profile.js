console.log("hello world");

const color = document.querySelector('#color');
color.addEventListener("click", function(){ alert("My favorite color is purple."); });

const place = document.querySelector('#place');
place.addEventListener("click", function(){ alert("My favorite place is my bed."); });

const ritual = document.querySelector('#ritual');
ritual.addEventListener("click", function(){ alert("My favorite ritual is my morning and night skincare routine."); });


button {
    padding: 15px;
    border: none;
}

#color {
    background-color: red;
}

#place {
    background-color: green;
}

#ritual {
    background-color: green;
}